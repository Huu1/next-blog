export const API=process.env.NODE_ENV==='production' ? 'http://47.98.216.176:3000' : 'http://localhost:3000';
