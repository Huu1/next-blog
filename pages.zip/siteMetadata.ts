export const siteMetadata = {
  title: 'hy的博客',
  headerTitle: '踏遍青山人未老，',
  author: 'Hu Yao',
  description: '记一些记不住的东西',
  email: '593119798@qq.com',
  github: 'https://github.com/Huu1',
}
