export const API='http://1.116.75.166:3000';

export const headerNavLinks = [
  { href: '/', title: '首页' },
  { href: '/tags', title: '标签' },
  { href: '/about', title: '关于我' },
]