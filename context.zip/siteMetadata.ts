export const siteMetadata = {
  title: "hy的博客",
  headerTitle: "踏遍青山人未老，",
  author: "Hu Yao",
  TStack: "React Angular",
  occupation: "前端开发",
  description: "记一些记不住的东西",
  email: "593119798@qq.com",
  github: "https://github.com/Huu1",
  selfIntroduction:`
  ### **你好啊**!
  ​   欢迎来到我的地盘🐎，下班闲时用\`nextJs react\`和 \`nestJs\` 写了这个博客，主要想记录一些工作和学习上遇到的知识点，有什么问题可以与联系哦！🤪
  `
};
