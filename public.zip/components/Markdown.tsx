import React from 'react';
import ReactMarkdown from 'react-markdown';
import {Prism as SyntaxHighlighter} from 'react-syntax-highlighter'
import {tomorrow } from 'react-syntax-highlighter/dist/cjs/styles/prism';

const renderers = {
  code: ({language, value}:any) => {
    return <SyntaxHighlighter style={tomorrow} language={language}  >{value}</SyntaxHighlighter>
  },
}

export default function Markdown(props:any) {
  return <ReactMarkdown renderers={renderers}  {...props} />;
}