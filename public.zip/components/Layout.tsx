import Header from "./Header";

export default function Layout({ children }: any) {
  return (
    <div
      className="App px-5 pt-10"
      style={{ minHeight: "100vh", margin: "0 auto", maxWidth: "1280px" }}
    >
      <Header />
      <main>{children}</main>
    </div>
  );
}
